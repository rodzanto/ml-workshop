# Create TensorFlowLiteObjectDetection component artifacts 

We need to modify the artifacts of the new TensorFlowLiteObjectDetection component for our RaspberryPi 64-bit OS Debian with a USB camera attached. 

The zip file with the artifacts is called "object_detection.zip". It includes a modifed version of "predictions_utils.py" to make it compatible with our RasperrryPi device and camera. 

This artifact should be stored in your S3 bucket and then referenced in the repice file of your component. 


